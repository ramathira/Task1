// App.jsx

import React from "react";
import DataContext from '../DataContext';

// import Users component
import UsersPage from "../pages/UsersPage";
const About = () => {
	return (
		<div>
		
			<UsersPage />
		
		</div>
	);
};

export default About;
