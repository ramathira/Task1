// UsersPage.js
import React, { useContext } from 'react';
import { DataContext } from '../DataContext';
import DataTable from '../atoms/DataTable';
import Pagination from '../atoms/Pagination';

function UsersPage() {
	var headStyle = {  
         fontSize: 40,  
         fontFamily: 'Neutra Text',  
         color: '#322625'  ,
		textAlign:'center'

      }  
	
const { userData=[], pagination, fetchData, changePageSize, changePage } = useContext(DataContext);

	const columnData = ['firstName', 'lastName', 'maidenName', 'age', 'gender', 'email', 'username','bloodGroup','eyeColor'];
if (!userData) {
    return <p>Loading...</p>;
  }
console.log("Context data:", { userData, pagination });
  return (
    <div>
      <h1 style = {headStyle} >Users</h1>
      {userData.length > 0 ? (
        <>
          <DataTable data={userData}  columns={columnData}/>     
		<Pagination pagination={pagination} fetchData={fetchData} changePageSize={changePageSize} changePage={changePage} />
  
   
        </>
      ) : (
         <p>No user data available.</p>
      )}
    </div>
  );
}

export default UsersPage;
