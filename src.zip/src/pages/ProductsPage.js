// ProductsPage.js
import React, { useContext } from 'react';
import { DataContext } from '../DataContext';
import DataTable from '../atoms/DataTable';
import Pagination from '../atoms/Pagination';

function ProductsPage() {

}

export default ProductsPage;
